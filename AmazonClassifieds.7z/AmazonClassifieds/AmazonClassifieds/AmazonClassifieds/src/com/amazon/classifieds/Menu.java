package com.amazon.classifieds;

import com.amazon.classifieds.controller.AuthenticationService;
import com.amazon.classifieds.controller.CategoryService;
import com.amazon.classifieds.controller.ClassifiedService;
import com.amazon.classifieds.controller.OrdersService;
import com.amazon.classifieds.db.DB;

import java.util.Scanner;

public class Menu {

    AuthenticationService auth = AuthenticationService.getInstance();

    ClassifiedService classifiedService = ClassifiedService.getInstance();

    CategoryService categoryService = CategoryService.getInstance();

    OrdersService ordersService =OrdersService.getInstance();

    Scanner scanner = new Scanner(System.in);
    public void showMainMenu() {

        // Initial Menu for the Application
        while(true) {
            System.out.println("1: Admin");
            System.out.println("2: Users");
            System.out.println("3: Quit");

            System.out.println("Select an Option");
            int choice = Integer.parseInt(scanner.nextLine());

            if (choice == 3) {
                System.out.println("Thank You For using Classifieds Application");

                // Close the DataBase Connection, when Users has exited the application :)


                DB db = DB.getInstance();
                db.closeConnection();
                scanner.close();
                break;
            }

            try {
                MenuFactory.getMenu(choice).showMenu();
            } catch (Exception e) {
                System.err.println("[Menu] [Exception] Invalid Choice..."+e);
            }



        }


    }

    public void showMenu() {
        System.out.println("Showing the Menu...");
    }


}
