package com.amazon.classifieds.db;


import com.amazon.classifieds.model.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDAO implements DAO<Users>{

    DB db = DB.getInstance();

    @Override
    public int insert(Users object) {
        String sql = "INSERT INTO Users (name, phone, email, password, address, department, type, account_status) VALUES ('"+object.name+"', '"+object.phone+"', '"+object.email+"', '"+object.password+"', '"+object.address+"', '"+object.department+"', '"+object.type+"', '"+object.account_status+"'"+")";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Users object) {
        String sql = "UPDATE Users set name = '"+object.name+"', phone='"+object.phone+"', password='"+object.password+"', address='"+object.address+"', department='"+object.department+"' WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Users object) {
        String sql = "DELETE FROM Users WHERE email = '"+object.email+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Users> retrieve() {

        String sql = "SELECT * from Users";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Users> Userss = new ArrayList<Users>();

        try {
            while(set.next()) {

                Users Users = new Users();

                // Read the row from ResultSet and put the data into Users Object
                Users.id = set.getInt("id");
                Users.name = set.getString("name");
                Users.phone = set.getString("phone");
                Users.email = set.getString("email");
                Users.password = set.getString("password");
                Users.address = set.getString("address");
                Users.department = set.getString("department");
                Users.type = set.getInt("type");
                Users.account_status=set.getString("account_status");
                Users.createdOn = set.getString("createdOn");

                Userss.add(Users);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Userss;
    }

    @Override
    public List<Users> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Users> Userss = new ArrayList<Users>();

        try {
            while(set.next()) {

                Users Users = new Users();

                // Read the row from ResultSet and put the data into Users Object
                Users.id = set.getInt("id");
                Users.name = set.getString("name");
                Users.phone = set.getString("phone");
                Users.email = set.getString("email");
                Users.password = set.getString("password");
                Users.address = set.getString("address");
                Users.department = set.getString("department");
                Users.type = set.getInt("type");
                Users.account_status=set.getString("account_status");
                Users.createdOn = set.getString("createdOn");

                Userss.add(Users);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Userss;
    }

    public int updateStatus(Users object)
    {
        String sql = "UPDATE Users set account_status = '"+object.account_status+"' WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

}

