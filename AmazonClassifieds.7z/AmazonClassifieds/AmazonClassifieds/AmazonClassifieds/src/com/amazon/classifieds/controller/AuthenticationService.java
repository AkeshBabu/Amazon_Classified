package com.amazon.classifieds.controller;


import com.amazon.classifieds.db.UserDAO;
import com.amazon.classifieds.db.UserDAO;
import com.amazon.classifieds.model.Orders;
import com.amazon.classifieds.model.Users;

import java.util.List;
import java.util.Scanner;

public class AuthenticationService {
    private static AuthenticationService service = new AuthenticationService();
    UserDAO dao = new UserDAO();

    Scanner scanner = new Scanner(System.in);

    public static AuthenticationService getInstance() {
        return service;
    }

    private AuthenticationService(){
//
//		Users Users1 = new Users();
//		Users1.id = 1;
//		Users1.name = "John Watson";
//		Users1.phone = "+91 99999 11111";
//		Users1.email = "jon@example.com";
//		Users1.password = "admin123";
//		Users1.address = "Redwood Shores";
//		Users1.department = "admin";
//      Users1.account_status="active";
//		Users1.type = 1;		// admin
//
//		Users Users2 = new Users();
//		Users2.id = 2;
//		Users2.name = "Fionna Flynn";
//		Users2.phone = "+91 99999 22222";
//		Users2.email = "fionna@example.com";
//		Users2.password = "fionna123";
//		Users2.address = "Country Homes";
//		Users2.department = "hr";
//		Users2.type = 2;		// Users or visitor
//      Users2.account_status="active";
//
//		// Add 2 Userss in DataBase
//		UsersDAO dao = new UsersDAO();
//		dao.insert(Users1);
//		dao.insert(Users2);

    }


    public boolean loginUsers(Users Users) {

        String sql = "SELECT * FROM Users WHERE email = '"+Users.email+"' AND password = '"+Users.password+"'";
        List<Users> Userss = dao.retrieve(sql);

        if(Userss.size() > 0) {
            Users u = Userss.get(0);
            Users.id = u.id;
            Users.name = u.name;
            Users.phone = u.phone;
            Users.email = u.email;
            Users.address = u.address;
            Users.department = u.department;
            Users.type = u.type;
            Users.account_status= u.account_status;
            Users.createdOn = u.createdOn;
            return true;
        }

        return false;
    }
    public boolean registerUsers(Users Users) {
        //int result = dao.insert(Users);
        //return result > 0;
        Users.account_status="active";
        return dao.insert(Users) > 0;
    }

    public boolean updateUsers(Users Users) {
        return dao.update(Users) > 0;
    }

    public void activateDeactivateUsers(){
        Users Users=new Users();
        System.out.println("Enter Users ID you want to Activate or Deactivate");
        Users.id= Integer.parseInt(scanner.nextLine());

        System.out.println("Enter 1 to Activate");
        System.out.println("Enter 2 to Deactivate");
        System.out.println("Enter Approval Choice: ");
        int ch = scanner.nextInt();
        if (ch==1){
            Users.account_status="Activated";
            int result= dao.updateStatus(Users);
            String message = (result > 0) ? "Account Activated Successfully" : "Updating  Request Failed. Try Again..";
            System.out.println(message);
        }
        else {
            Users.account_status="Deactivated";
            int result= dao.updateStatus(Users);
            String message = (result > 0) ? "Account Deactivated Successfully" : "Updating  Request Failed. Try Again..";
            System.out.println(message);
        }
    }

    public void viewAllUsers(){

        List<Users> objects = null;


        //String sql = "SELECT * from Users ";
        objects = dao.retrieve();


        for(Users object : objects) {
            object.prettyPrint();
        }
    }

}

