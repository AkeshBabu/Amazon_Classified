package com.amazon.classifieds.model;

import java.util.Scanner;

/*
create table Orders(
        id INT PRIMARY KEY AUTO_INCREMENT,
        classifiedId INT,
        from_Users_id INT,
        to_Users_id INT ,
        proposedPrice INT,
        status INT,
        lastUpdatedOn DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (classifiedId) REFERENCES Classified(id),
        FOREIGN KEY (from_Users_id) REFERENCES Users(id),
        FOREIGN KEY (to_Users_id) REFERENCES Users(id)
        );

 */
public class Orders {

    public int id;

    public int classifiedId;

    public int from_Users_id;

    public int to_Users_id;

    public int proposedPrice;

    public int status;// 0- requested for purchase , 1- approved ,2-rejected , 3- payment processed/sold

    public String lastUpdatedOn;

    public Orders() {
    }

    public Orders(int id, int classifiedId, int from_Users_id, int to_Users_id, int proposedPrice, int status,String lastUpdatedOn) {
        this.id = id;
        this.classifiedId = classifiedId;
        this.from_Users_id = from_Users_id;
        this.to_Users_id = to_Users_id;
        this.proposedPrice = proposedPrice;
        this.status = status;
        this.lastUpdatedOn=lastUpdatedOn;
    }
    public void getDetails() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Capturing Order Details....");

        System.out.println("Enter the Classified ID");
        classifiedId=Integer.parseInt(scanner.nextLine());
        System.out.println("Enter the Users ID for Buy Request");
        to_Users_id=Integer.parseInt(scanner.nextLine());
        System.out.println("Enter the proposed Price");
        proposedPrice=Integer.parseInt(scanner.nextLine());

    }


    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Classified Id:\t\t"+classifiedId);
        System.out.println("From Users Id:\t\t"+from_Users_id);
        System.out.println("To Users Id:\t\t"+to_Users_id);
        System.out.println("Proposed Price:\t"+proposedPrice);
        System.out.println("Status:\t"+status);
        System.out.println("Last Updated On:\t"+lastUpdatedOn);
        ;

        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Orders{" +
                "id=" + id +
                ", classifiedId=" + classifiedId +
                ", from_Users_id=" + from_Users_id +
                ", to_Users_id=" + to_Users_id +
                ", proposedPrice=" + proposedPrice +
                ", status=" + status +
                '}';
    }
}
