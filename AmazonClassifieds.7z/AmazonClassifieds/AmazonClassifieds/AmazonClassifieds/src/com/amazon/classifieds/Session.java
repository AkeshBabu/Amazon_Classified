package com.amazon.classifieds;

import com.amazon.classifieds.model.Users;

public class Session {

    public static Users Users = null;
}
