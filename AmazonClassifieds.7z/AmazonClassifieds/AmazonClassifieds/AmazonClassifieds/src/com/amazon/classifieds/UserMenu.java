package com.amazon.classifieds;

import com.amazon.classifieds.model.Users;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Date;

public class UserMenu extends Menu{

    private static UserMenu menu = new UserMenu();

    public static UserMenu getInstance() {
        return menu;
    }

    private UserMenu() {

    }

    public void showMenu() {

        System.out.println("Navigating to Users Menu...");

        System.out.println("1: Register");
        System.out.println("2: Login");
        System.out.println("3: Cancel");

        System.out.println("Enter Your Choice: ");
        int initialChoice = Integer.parseInt(scanner.nextLine());

        boolean result = false;

        Users Users = new Users();


        if(initialChoice == 1) {

            System.out.println("Enter Your Name:");
            Users.name = scanner.nextLine();

            System.out.println("Enter Your Phone:");
            Users.phone = scanner.nextLine();

            System.out.println("Enter Your Email:");
            Users.email = scanner.nextLine();

            System.out.println("Enter Your Password:");
            Users.password = scanner.nextLine();

            try {
                // Hash the Password of Users :)
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(Users.password.getBytes(StandardCharsets.UTF_8));
                Users.password = Base64.getEncoder().encodeToString(hash);
            }catch (Exception e) {
                System.err.println("Something Went Wrong: "+e);
            }

            System.out.println("Enter Your Address:");
            Users.address = scanner.nextLine();

            System.out.println("Enter Your Department:");
            Users.department = scanner.nextLine();

            // As we know, Users is registering :)
            Users.type = 2;
            Users.account_status="Activated";

            result = auth.registerUsers(Users);

        }else if(initialChoice == 2) {

            System.out.println("Enter Your Email:");
            Users.email = scanner.nextLine();

            System.out.println("Enter Your Password:");
            Users.password = scanner.nextLine();

            try {
                // Encoded to Hash i.e. SHA-256 so as to match correctly
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(Users.password.getBytes(StandardCharsets.UTF_8));
                Users.password = Base64.getEncoder().encodeToString(hash);
            }catch (Exception e) {
                System.err.println("Something Went Wrong: "+e);
            }

            result = auth.loginUsers(Users);

        }else if(initialChoice == 3) {
            System.out.println("Thank You for Using Bus Pass App");
        }else {
            System.err.println("Invalid Choice...");
            System.out.println("Thank You for Using Bus Pass App");
        }


        if(result && Users.type == 2) {

            // Link the Users to the Session Users :)
            Session.Users = Users;

            System.out.println("^^^^^^^^^^^^^^^^^^^");
            System.out.println("Welcome to Users App");
            System.out.println("Hello, "+Users.name);
            System.out.println("Its: "+new Date());
            System.out.println("^^^^^^^^^^^^^^^^^^^");

            boolean quit = false;

            while(true) {

                System.out.println("1: View All Classified");
                System.out.println("2: Post a Classified");
                System.out.println("3: View my Posts");
                System.out.println("4: Make a Buy Request");
                System.out.println("5: View Buy Request");
                System.out.println("6: My Profile");
                System.out.println("7: Quit Users App");
                System.out.println("Select an Option");

                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        //routeService.viewRoutes();
                        classifiedService.viewClassifiedAdmin();
                        break;

                    case 2:
                        //routeService.viewRoutes();
                        System.out.println("****************************");
                        //passService.requestPass();
                        classifiedService.addClassified();
                        break;

                    case 3:
                        //passService.viewPassRequestsByUsers(BusPassSession.Users.id);
                        classifiedService.viewClassifiedUsers();
                        break;

                    case 4:
                        classifiedService.viewClassifiedUsers();
                        System.out.println("****************************");
                        ordersService.addOrders();
                        break;

                    case 5:
                        //feedbackService.createFeedback();
                        ordersService.viewBuyRequest();
                        break;

                    case 6:
                        System.out.println("My Profile");
                        Users.prettyPrint();

                        System.out.println("Do you wish to update Profile (1: update 0: cancel)");

                        choice = Integer.parseInt(scanner.nextLine());


                        if(choice == 1) {


                            System.out.println("Enter Your Name:");
                            String name = scanner.nextLine();
                            if(!name.isEmpty()) {
                                Users.name = name;
                            }

                            System.out.println("Enter Your Phone:");
                            String phone = scanner.nextLine();
                            if(!phone.isEmpty()) {
                                Users.phone = phone;
                            }

                            System.out.println("Enter Your Password:");
                            String password = scanner.nextLine();
                            if(!password.isEmpty()) {
                                Users.password = password;
                            }

                            System.out.println("Enter Your Address:");
                            String address = scanner.nextLine();
                            if(!address.isEmpty()) {
                                Users.address = address;
                            }

                            System.out.println("Enter Your Department:");
                            String department = scanner.nextLine();
                            if(!department.isEmpty()) {
                                Users.department = department;
                            }

                            if(auth.updateUsers(Users)) {
                                System.out.println("Profile Updated Successfully");
                            }else {
                                System.err.println("Profile Update Failed...");
                            }

                        }
                        break;

                    case 7:
                        System.out.println("Thank You for Using Users App !!");
                        quit = true;
                        break;

                    default:
                        System.err.println("Invalid Choice...");
                        break;
                }

                if(quit) {
                    break;
                }

            }
        }else {
            System.err.println("Authentication Failed..");
        }
    }
}
