package com.amazon.classifieds.db;

import com.amazon.classifieds.model.Classified;
import com.amazon.classifieds.model.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClassifiedDAO implements DAO<Classified>{

    DB db = DB.getInstance();

    @Override
    public int insert(Classified object) {
        String sql = "INSERT INTO Classified (UsersId,headline, name_of_prod, brand, condition_type, description, price, pic_url, category_id, status) VALUES ('"+object.UsersId+"', '"+object.headline+"', '"+object.name_of_prod+"', '"+object.brand+"', '"+object.condition_type+"', '"+object.description+"', '"+object.price+"', '"+object.pic_url+"', '"+object.category_id+"', '"+object.status+"'"+")";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Classified object) {
        String sql = "UPDATE Classified set headline = '"+object.headline+"', name_of_prod='"+object.name_of_prod+"', brand='"+object.brand+"', condition_type='"+object.condition_type+"', description='"+object.description+"', price='"+object.price+"', pic_url='"+object.pic_url+"', category_id='"+object.category_id+"', status='"+object.status+"' WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Classified object) {
        String sql = "DELETE FROM Users WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Classified> retrieve() {

        String sql = "SELECT * from Classified";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Classified> classifieds = new ArrayList<Classified>();

        try {
            while(set.next()) {

                Classified classified = new Classified();

                // Read the row from ResultSet and put the data into Users Object
                classified.id = set.getInt("id");
                classified.UsersId = set.getInt("UsersId");
                classified.headline = set.getString("headline");
                classified.name_of_prod = set.getString("name_of_prod");
                classified.brand = set.getString("brand");
                classified.condition_type = set.getInt("condition_type");
                classified.description = set.getString("description");
                classified.price = set.getInt("price");
                classified.pic_url = set.getString("pic_url");
                classified.category_id = set.getInt("category_id");
                classified.status = set.getInt("status");
                classified.createdOn = set.getString("createdOn");

                classifieds.add(classified);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return classifieds;
    }

    @Override
    public List<Classified> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Classified> classifieds = new ArrayList<Classified>();

        try {
            while(set.next()) {

                Classified classified = new Classified();

                // Read the row from ResultSet and put the data into Users Object
                classified.id = set.getInt("id");
                classified.UsersId = set.getInt("UsersId");
                classified.headline = set.getString("headline");
                classified.name_of_prod = set.getString("name_of_prod");
                classified.brand = set.getString("brand");
                classified.condition_type = set.getInt("condition_type");
                classified.description = set.getString("description");
                classified.price = set.getInt("price");
                classified.pic_url = set.getString("pic_url");
                classified.category_id = set.getInt("category_id");
                classified.status = set.getInt("status");
                classified.createdOn = set.getString("createdOn");

                classifieds.add(classified);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return classifieds;
    }
}
