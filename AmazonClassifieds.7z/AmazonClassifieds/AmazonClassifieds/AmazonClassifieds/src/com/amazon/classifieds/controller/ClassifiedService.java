package com.amazon.classifieds.controller;

import com.amazon.classifieds.Session;
import com.amazon.classifieds.db.ClassifiedDAO;
import com.amazon.classifieds.db.UserDAO;
import com.amazon.classifieds.model.Category;
import com.amazon.classifieds.model.Classified;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ClassifiedService {

    private static ClassifiedService classifiedService = new ClassifiedService();
    ClassifiedDAO dao = new ClassifiedDAO();

    Scanner scanner = new Scanner(System.in);

    public static ClassifiedService getInstance() {
        return classifiedService;
    }

    private ClassifiedService() {

    }

    public void addClassified(){
        Classified classified=new Classified();
        classified.getDetails();
        classified.UsersId = Session.Users.id;
        classified.status=0; // Initial status for the add 0 for pending
        int result = dao.insert(classified);

        String message = (result > 0) ? "Classified Added Successfully" : "Something went wrong. Try Again..";
        System.out.println(message);

    }

    public void deleteClassified() {
        Classified classified=new Classified();
        System.out.println("Enter Classified ID to be deleted: ");
        classified.id = scanner.nextInt();
        int result = dao.delete(classified);
        String message = (result > 0) ? "Classified Deleted Successfully" : "Deleting Classified Failed. Try Again..";
        System.out.println(message);
    }

    public void approveRejectClassified() {
        Classified classified = new Classified();
        System.out.println("Enter Classified ID: ");
        classified.id = scanner.nextInt();

        System.out.println("Enter 1 to Approve");
        System.out.println("Enter 2 to Reject");
        System.out.println("Enter Approval Choice: ");
        classified.status = scanner.nextInt();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        Calendar calendar = Calendar.getInstance();
        Date date1 = calendar.getTime();
        classified.createdOn = dateFormat.format(date1);

//        if(classified.status == 1) {
//            calendar.add(Calendar.YEAR, 1);
//            Date date2 = calendar.getTime();
//           // pass.validTill = dateFormat.format(date2);
//        }else {
//            //pass.validTill = pass.approvedRejectedOn;
//        }

        int result = dao.update(classified);
        String message = (result > 0) ? "Classified Request Updated Successfully" : "Updating  Request Failed. Try Again..";
        System.out.println(message);
    }

    public void viewClassifiedAdmin() {

        System.out.println("Enter 1 to view approved Classifieds");
        System.out.println("Or 0 for All Classified");
        System.out.println("Enter your choice: ");

        int viewChoice = scanner.nextInt();

        List<Classified> objects = null;

        if(viewChoice == 0) {
            objects = dao.retrieve();
        }else {
            String sql = "SELECT * from Classified where status = "+1;
            objects = dao.retrieve(sql);
        }

        for(Classified object : objects) {
            object.prettyPrint();
        }
    }

    public void viewClassified(){

        List<Classified> objects = null;

        objects = dao.retrieve();

        for(Classified object : objects) {
            object.prettyPrint();
        }

    }

    public void viewClassifiedUsers() {

        System.out.println("Enter 1 to view Classified created by Users");
        System.out.println("Or 0 for All Classified");
        System.out.println("Enter your choice: ");

        int viewChoice = scanner.nextInt();
        int Users_id=Session.Users.id;

        List<Classified> objects = null;

        if(viewChoice == 0) {
            String sql = "SELECT * from Classified where UsersId = "+Users_id;
            objects = dao.retrieve(sql);
        }else {
            String sql = "SELECT * from Classified where status = "+1;
            objects = dao.retrieve(sql);
        }

        for(Classified object : objects) {
            object.prettyPrint();
        }
    }






}
