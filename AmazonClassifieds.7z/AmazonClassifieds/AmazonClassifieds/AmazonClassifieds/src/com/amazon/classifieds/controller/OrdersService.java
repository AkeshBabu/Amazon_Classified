package com.amazon.classifieds.controller;

import com.amazon.classifieds.Session;
import com.amazon.classifieds.db.ClassifiedDAO;
import com.amazon.classifieds.db.OrdersDAO;
import com.amazon.classifieds.model.Classified;
import com.amazon.classifieds.model.Orders;

import java.util.List;
import java.util.Scanner;

public class OrdersService {

    private static OrdersService ordersService = new OrdersService();
    OrdersDAO dao = new OrdersDAO();

    Scanner scanner = new Scanner(System.in);

    public static OrdersService getInstance() {
        return ordersService;
    }

    private OrdersService() {

    }

    public void addOrders(){
        Orders orders=new Orders();
        orders.getDetails();
        orders.from_Users_id = Session.Users.id;
        orders.status=0; // Initial status for the add 0 for Requested
        int result = dao.insert(orders);

        String message = (result > 0) ? "Buy Request Made Successfully" : "Something went wrong. Try Again..";
        System.out.println(message);

    }

    public void viewBuyRequest() {


        Orders orders=new Orders();

        int Users_id=Session.Users.id;

        List<Orders> objects = null;


            String sql = "SELECT * from Orders where to_Users_id = "+Users_id;
            objects = dao.retrieve(sql);


        for(Orders object : objects) {
            object.prettyPrint();
        }

        System.out.println("Enter 1 to Approve the buy request");
        System.out.println("Enter 2 to Reject the buy request ");
        System.out.println("Enter your choice: ");

        int viewChoice = scanner.nextInt();
        orders.status=viewChoice;

        int result = dao.update(orders);
        String message = (result > 0) ? "Buy Request Updated Successfully" : "Updating  Request Failed. Try Again..";
        System.out.println(message);



    }

    public void viewAllOrders(){
       // Orders orders=new Orders();

        List<Orders> objects = null;


        //String sql = "SELECT * from Orders ";
        objects = dao.retrieve();


        for(Orders object : objects) {
            object.prettyPrint();
        }

    }

}
