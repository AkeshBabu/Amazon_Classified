package com.amazon.classifieds.db;

import com.amazon.classifieds.model.Classified;
import com.amazon.classifieds.model.Orders;
import com.amazon.classifieds.model.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrdersDAO implements DAO<Orders>{
    DB db = DB.getInstance();

    @Override
    public int insert(Orders object) {
        String sql = "INSERT INTO Orders (classifiedID,from_Users_id, to_Users_id, proposedPrice, status) VALUES ('"+object.classifiedId+"', '"+object.from_Users_id+"', '"+object.to_Users_id+"', '"+object.proposedPrice+"', '"+object.status+"'"+")";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Orders object) {
        String sql = "UPDATE Orders set status = '"+object.status+"' WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Orders object) {
        String sql = "DELETE FROM Orders WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Orders> retrieve() {

        String sql = "SELECT * from Orders";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Orders> orders = new ArrayList<Orders>();

        try {
            while(set.next()) {

                Orders order = new Orders();

                // Read the row from ResultSet and put the data into Users Object
                order.id = set.getInt("id");
                order.classifiedId = set.getInt("classifiedId");
                order.from_Users_id = set.getInt("from_Users_id");
                order.to_Users_id = set.getInt("to_Users_id");
                order.proposedPrice = set.getInt("proposedPrice");
                order.status = set.getInt("status");
                order.lastUpdatedOn = set.getString("lastUpdatedOn");


                orders.add(order);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return orders;
    }

    @Override
    public List<Orders> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Orders> orders = new ArrayList<Orders>();

        try {
            while(set.next()) {

                Orders order = new Orders();

                // Read the row from ResultSet and put the data into Users Object
                order.id = set.getInt("id");
                order.classifiedId = set.getInt("classifiedId");
                order.from_Users_id = set.getInt("from_Users_id");
                order.to_Users_id = set.getInt("to_Users_id");
                order.proposedPrice = set.getInt("proposedPrice");
                order.status = set.getInt("status");
                order.lastUpdatedOn = set.getString("lastUpdatedOn");


                orders.add(order);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return orders;
    }
    public int updateStatus(Orders object)
    {
        String sql = "UPDATE Orders set status = '"+object.status+"' WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

}
