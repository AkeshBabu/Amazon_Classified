package com.amazon.classifieds;

import com.amazon.classifieds.model.Users;

import java.util.Date;

public class AdminMenu extends Menu{

    private static AdminMenu menu = new AdminMenu();

    public static AdminMenu getInstance() {
        return menu;
    }

    private AdminMenu() {

    }

    public void showMenu() {

        System.out.println("Navigating to Admin Menu...");

        // Login Code should come before the Menu becomes Visible to the Admin
        Users adminUsers = new Users();

        System.out.println("Enter Your Email:");
        adminUsers.email = scanner.nextLine();

        System.out.println("Enter Your Password:");
        adminUsers.password = scanner.nextLine();

        boolean result = auth.loginUsers(adminUsers);

        if(result && adminUsers.type == 1) {

            // Link the Admin Users to the Session Users :)
            Session.Users = adminUsers;

            System.out.println("*********************");
            System.out.println("Welcome to Admin App");
            System.out.println("Hello, "+adminUsers.name);
            System.out.println("Its: "+new Date());
            System.out.println("*********************");

            boolean quit = false;

            while(true) {
                System.out.println("1: Manage Classifieds"); // here we mean -> add, update, delete and view :)
                System.out.println("2: Manage Userss");
                System.out.println("3: Manage Categories");
                System.out.println("4: Generate Reports");
                System.out.println("5: Quit Admin App");
                System.out.println("Select an Option");

                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:

                        System.out.println("1: Approve/Reject Classifieds");
                        System.out.println("2: View  Classifieds");
                        System.out.println("3: Add Classified");
                        System.out.println("4: Remove Classified");

                        System.out.println("Enter Your Choice: ");
                        int classifiedChoice = Integer.parseInt(scanner.nextLine());

                        if(classifiedChoice == 1) {
                            //routeService.addRoute();
                            classifiedService.approveRejectClassified();
                        }
                        else if(classifiedChoice == 2) {
                            //routeService.updateRoute();
                            classifiedService.viewClassifiedAdmin();

                        }
                        else if (classifiedChoice == 3) {

                            classifiedService.addClassified();
                        }else if(classifiedChoice == 4) {
                           // routeService.viewRoutes();
                            classifiedService.deleteClassified();
                        }else {
                            System.err.println("Invalid  Choice..");
                        }

                        break;

                    case 2:

                        System.out.println("1: Activate/Deactivate Users");
                        //System.out.println("2:  Users");
//

                        System.out.println("Enter Your Choice: ");
                        int UsersChoice = Integer.parseInt(scanner.nextLine());

                        if(UsersChoice == 1) {
                           // routeService.addStop();

                            auth.activateDeactivateUsers();
                        }
//                        else if(UsersChoice == 2) {
//                          //  routeService.updateStop();
//                        }else if (UsersChoice == 3) {
//                          //  routeService.deleteStop();
//                        }else if(UsersChoice == 4) {
//                         //   routeService.viewStops();
//                        }
                        else {
                            System.err.println("Invalid  Choice..");
                        }

                        break;

                    case 3:

                        System.out.println("1: Add Categories");
                        System.out.println("2: Update Categories");
                        System.out.println("3: Delete Categories");
                        System.out.println("4: View Categories");

                        System.out.println("Enter Your Choice: ");
                        int categoryChoice = Integer.parseInt(scanner.nextLine());

                        if(categoryChoice == 1) {
                           // routeService.addVehicle();
                            categoryService.addCategory();
                        }else if(categoryChoice == 2) {
                          //  routeService.updateVehicle();
                            categoryService.updateCategory();
                        }else if (categoryChoice == 3) {
                          //  routeService.deleteVehicle();
                            categoryService.deleteCategory();
                        }else if(categoryChoice == 4) {
                          //  routeService.viewVehicles();
                            categoryService.viewCategory();
                        }else {
                            System.err.println("Invalid  Choice..");
                        }

                        break;

                    case 4:

                        System.out.println("1: View Post Report");
                        System.out.println("2: View Orders Report");
                        System.out.println("3: View Userss Report");
                        System.out.println("4: View Categories Report");

                        System.out.println("Enter Your Choice: ");
                        int reportChoice = Integer.parseInt(scanner.nextLine());

                        if(reportChoice == 1) {
                           // passService.viewPassRequests();
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("View Posts Report");
                            classifiedService.viewClassified();
                        }else if(reportChoice == 2) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("View Orders Report");
                            ordersService.viewAllOrders();
                        }else if(reportChoice == 3) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("Users Report");
                            auth.viewAllUsers();
                        }else if (reportChoice == 4) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("Category Report");
                            categoryService.viewCategory();
                        }else {
                            System.err.println("Invalid  Choice..");
                        }

                        break;



                    case 5:
                        System.out.println("Thank You for Using Admin App !!");
                        quit = true;
                        break;

                    default:
                        System.err.println("Invalid Choice...");
                        break;
                }

                if(quit) {
                    break;
                }

            }
        }else {
            System.err.println("Invalid Credentials. Please Try Again !!");
        }
    }

}

