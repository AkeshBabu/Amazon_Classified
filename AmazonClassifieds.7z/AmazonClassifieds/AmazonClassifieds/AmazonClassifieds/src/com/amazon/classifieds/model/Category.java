package com.amazon.classifieds.model;

/*
create table Category(
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(256),
        createdOn DATETIME DEFAULT CURRENT_TIMESTAMP
        );

 */
public class Category {

    public int id;

    public String title;

    public String createdOn;

    public Category() {
    }

    public Category(int id, String title, String createdOn) {
        this.id = id;
        this.title = title;
        this.createdOn = createdOn;
    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("ID:\t\t"+id);
        System.out.println("Title:\t\t"+title);
        System.out.println("CreatedOn:\t\t"+createdOn);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", createdOn='" + createdOn + '\'' +
                '}';
    }
}
