package com.amazon.classifieds.controller;

import com.amazon.classifieds.Session;
import com.amazon.classifieds.db.CategoryDAO;
import com.amazon.classifieds.db.ClassifiedDAO;
import com.amazon.classifieds.model.Category;
import com.amazon.classifieds.model.Classified;

import java.util.List;
import java.util.Scanner;

public class CategoryService {

    private static CategoryService categoryService = new CategoryService();
    CategoryDAO dao = new CategoryDAO();

    Scanner scanner = new Scanner(System.in);

    public static CategoryService getInstance() {
        return categoryService;
    }

    private CategoryService() {

    }

    public void addCategory(){
        Category category=new Category();
        System.out.println("Enter a title for the category");
        category.title=scanner.nextLine();
        int result = dao.insert(category);

        String message = (result > 0) ? "Category Added Successfully" : "Something went wrong. Try Again..";
        System.out.println(message);

    }

    public void updateCategory(){
        Category category=new Category();
        System.out.println("Enter the category ID to update");
        category.id=Integer.parseInt(scanner.nextLine());

        System.out.println("Enter New Title");

        category.title = scanner.nextLine();
        int result = dao.update(category);
        String message = (result > 0) ? "Category Updated Successfully" : "Updating  Request Failed. Try Again..";
        System.out.println(message);
    }

    public void deleteCategory(){
        Category category=new Category();
        System.out.println("Enter the category title to delete");
        category.title=scanner.nextLine();

        int result = dao.delete(category);
        String message = (result > 0) ? "Category Deleted Successfully" : "Delete  Request Failed. Try Again..";
        System.out.println(message);
    }

    public void viewCategory(){
        Category category=new Category();

        List<Category> objects = null;

        objects = dao.retrieve();

        for(Category object : objects) {
            object.prettyPrint();
        }
    }
}
