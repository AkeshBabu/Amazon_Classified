package com.amazon.classifieds.model;

import java.util.Scanner;

/*
create table Classified(
        id INT PRIMARY KEY AUTO_INCREMENT,
        UsersId INT,
        headline VARCHAR(256),
        name_of_prod VARCHAR(256),
        brand VARCHAR(256) ,
        condition_type INT,
        description VARCHAR(256),
        price INT,
        pic_url VARCHAR(256),
        category_id INT,
        status INT,
        createdOn DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES Category(id),
        FOREIGN KEY (UsersId) REFERENCES Users(id)
        );

 */
public class Classified {

    public int id;

    public int UsersId;

    public String headline;

    public String name_of_prod;

    public String brand;

    public int condition_type;// 1-New , 2-Lightly Used,3-Medium Used,4-Heavy Used,5-Damaged/Dented,6-Not Working

    public String description;

    public int price;

    public String pic_url;

    public int category_id;

    public int status;//0-Pending, 1-approved , 2-Rejected,3-Sold

    public String createdOn;

    public Classified() {
    }

    public Classified(int id, int UsersId, String headline, String name_of_prod, String brand, int condition_type, String description, int price, String pic_url, int category_id, int status, String createdOn) {
        this.id = id;
        this.UsersId=UsersId;
        this.headline = headline;
        this.name_of_prod = name_of_prod;
        this.brand = brand;
        this.condition_type = condition_type;
        this.description = description;
        this.price = price;
        this.pic_url = pic_url;
        this.category_id = category_id;
        this.status = status;
        this.createdOn = createdOn;
    }

    public void getDetails() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Capturing Classified Details....");

        System.out.println("Enter the headline");
        headline=scanner.nextLine();
        System.out.println("Enter the name of product");
        name_of_prod=scanner.nextLine();
        System.out.println("Enter the brand");
        brand=scanner.nextLine();
        System.out.println("Enter the condition type");
        System.out.println("Press 1 for New");
        System.out.println("Press 2 for Lightly Used");
        System.out.println("Press 3 for Moderately Used");
        System.out.println("Press 4 for Heavily Used");
        System.out.println("Press 5 for Damaged/Dented");
        System.out.println("Press 6 for Not Working");

        condition_type = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter Description:");
        description = scanner.nextLine();

        System.out.println("Enter Price");
        price=Integer.parseInt(scanner.nextLine());

        System.out.println("Enter Picture Url");
        pic_url=scanner.nextLine();
        //Display Categories here
        System.out.println("Enter Category Id");
        category_id=Integer.parseInt(scanner.nextLine());



    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Headline:\t\t"+headline);
        System.out.println("Name of Product:\t\t"+name_of_prod);
        System.out.println("Brand:\t\t"+brand);
        System.out.println("Condition:\t"+condition_type);
        System.out.println("Description:\t"+description);
        System.out.println("Price:\t"+price);
        System.out.println("Picture Url:\t"+pic_url);
        System.out.println("Category Id:\t"+category_id);
        System.out.println("Status:\t"+status);
        System.out.println("CreatedOn:\t"+createdOn);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Classified{" +
                "id=" + id +
                ", headline='" + headline + '\'' +
                ", name_of_prod='" + name_of_prod + '\'' +
                ", brand='" + brand + '\'' +
                ", condition='" + condition_type + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", pic_url='" + pic_url + '\'' +
                ", category_id=" + category_id +
                ", status=" + status +
                ", createdOn='" + createdOn + '\'' +
                '}';
    }
}
